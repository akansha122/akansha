import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EventComponent } from './event/event.component';
import { IndexComponent } from './index/index.component';
import { ShivajiEventComponent } from './shivaji-event/shivaji-event.component';
import { NaraliEventComponent } from './narali-event/narali-event.component';
import { CustomerFormComponent } from './customer-form/customer-form.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CustomerService } from './customer.service';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { MahabaleshwarComponent } from './mahabaleshwar/mahabaleshwar.component';
import { LonavlaComponent } from './lonavla/lonavla.component';
import { MumbaiComponent } from './mumbai/mumbai.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    EventComponent,
    IndexComponent,
    ShivajiEventComponent,
    NaraliEventComponent,
    CustomerFormComponent,
   
    MahabaleshwarComponent,
    LonavlaComponent,
    MumbaiComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule
  
  ],
  providers: [CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
