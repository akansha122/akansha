import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lonavla',
  templateUrl: './lonavla.component.html',
  styleUrls: ['./lonavla.component.css']
})
export class LonavlaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
