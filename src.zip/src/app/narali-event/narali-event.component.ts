import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-narali-event',
  templateUrl: './narali-event.component.html',
  styleUrls: ['./narali-event.component.css']
})
export class NaraliEventComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
