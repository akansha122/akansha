import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NaraliEventComponent } from './narali-event.component';

describe('NaraliEventComponent', () => {
  let component: NaraliEventComponent;
  let fixture: ComponentFixture<NaraliEventComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NaraliEventComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NaraliEventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
