import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shivaji-event',
  templateUrl: './shivaji-event.component.html',
  styleUrls: ['./shivaji-event.component.css']
})
export class ShivajiEventComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
