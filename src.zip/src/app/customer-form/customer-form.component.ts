import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.css']
})
export class CustomerFormComponent implements OnInit {
customer:Customer={
  
    customerId:1,
    customerName:"akansha",
    emailId:"akansha@gmail.com",
    contactNo:8966978321,
    gender:"female",
    password:"1122"
  
}
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
  }
  onSubmit() {
    console.log(this.customer);
    this.customerService.addCustomer(this.customer).subscribe();
  }

}
