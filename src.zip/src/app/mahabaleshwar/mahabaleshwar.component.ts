import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mahabaleshwar',
  templateUrl: './mahabaleshwar.component.html',
  styleUrls: ['./mahabaleshwar.component.css']
})
export class MahabaleshwarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
