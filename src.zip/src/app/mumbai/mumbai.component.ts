import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mumbai',
  templateUrl: './mumbai.component.html',
  styleUrls: ['./mumbai.component.css']
})
export class MumbaiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
