import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EventComponent } from './event/event.component';
import { IndexComponent } from './index/index.component';
import { ShivajiEventComponent } from './shivaji-event/shivaji-event.component';
import { CustomerFormComponent } from './customer-form/customer-form.component';
import { LoginComponent } from './login/login.component';


const routes: Routes = [
  {path:'event', component:EventComponent},
  {path:'index1', component:IndexComponent},
  {path:'shivaji', component:ShivajiEventComponent},
  {path:'form', component:CustomerFormComponent},
  {path:'login', component:LoginComponent},
  {path:'', redirectTo:'/event',pathMatch:'full'},
  {path:'**', redirectTo:'/event',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
