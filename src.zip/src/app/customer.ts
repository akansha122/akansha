export class Customer {
    customerId:number;
    customerName:string;
    emailId:string;
    contactNo:number;
    gender:string;
    password:string;
}
